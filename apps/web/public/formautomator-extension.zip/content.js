"use strict";
(() => {
  // src/selector.ts
  function buildSelectorCandidates(el) {
    const candidates = [];
    const tag = el.tagName.toLowerCase();
    if (el.id && !isEphemeralFrameworkId(el.id)) {
      const sel = `#${CSS.escape(el.id)}`;
      if (isUnique(sel)) candidates.push(sel);
    }
    const name = el.getAttribute("name");
    if (name) {
      const sel = `${tag}[name="${escapeAttrValue(name)}"]`;
      if (isUnique(sel)) candidates.push(sel);
    }
    const ariaLabel = el.getAttribute("aria-label");
    if (ariaLabel) {
      const sel = `${tag}[aria-label="${escapeAttrValue(ariaLabel)}"]`;
      if (isUnique(sel)) candidates.push(sel);
    }
    const placeholder = el.getAttribute("placeholder");
    if (placeholder) {
      const sel = `${tag}[placeholder="${escapeAttrValue(placeholder)}"]`;
      if (isUnique(sel)) candidates.push(sel);
    }
    if (tag === "input") {
      const associatedLabel = "labels" in el ? el.labels?.[0] : void 0;
      if (associatedLabel) {
        const text2 = (associatedLabel.textContent || "").trim().replace(/\s+/g, " ");
        const cleaned = text2.replace(/\s+[\d][\d,]*$/, "").trim();
        if (cleaned && cleaned.length <= 80) {
          const escaped = cleaned.replace(/"/g, '\\"');
          candidates.push(
            associatedLabel.contains(el) ? `label:has-text("${escaped}") input` : `xpath=//label[contains(normalize-space(.), "${escaped}")]/following::input[1]`
          );
        }
      }
    }
    const text = (el.textContent || "").trim().replace(/\s+/g, " ");
    const isTextCarrier = tag === "button" || tag === "a" || el.getAttribute("role") === "button";
    if (text && text.length <= 60 && isTextCarrier) {
      candidates.push(`${tag}:text("${text.replace(/"/g, '\\"')}")`);
    }
    candidates.push(buildStructuralPath(el));
    return candidates;
  }
  function isUnique(selector) {
    try {
      return document.querySelectorAll(selector).length === 1;
    } catch {
      return false;
    }
  }
  function isEphemeralFrameworkId(id) {
    return /^:.+:$/.test(id);
  }
  function escapeAttrValue(value) {
    return value.replace(/"/g, '\\"');
  }
  function buildStructuralPath(el) {
    const parts = [];
    let node = el;
    for (let depth = 0; node && depth < 6 && node !== document.body; depth++) {
      const tag = node.tagName.toLowerCase();
      const parent = node.parentElement;
      if (!parent) {
        parts.unshift(tag);
        break;
      }
      const currentTag = node.tagName;
      const siblings = Array.from(parent.children).filter((c) => c.tagName === currentTag);
      const index = siblings.indexOf(node) + 1;
      parts.unshift(siblings.length > 1 ? `${tag}:nth-of-type(${index})` : tag);
      const partial = parts.join(" > ");
      if (isUnique(partial)) return partial;
      node = parent;
    }
    return parts.join(" > ") || el.tagName.toLowerCase();
  }

  // src/labels.ts
  function detectFieldLabel(el) {
    const associated = "labels" in el ? el.labels : null;
    if (associated && associated.length > 0) {
      const text = associated[0].textContent?.trim();
      if (text) return stripTrailingCountBadge(text);
    }
    const ariaLabel = el.getAttribute("aria-label");
    if (ariaLabel?.trim()) return stripTrailingCountBadge(ariaLabel.trim());
    const ariaLabelledBy = el.getAttribute("aria-labelledby");
    if (ariaLabelledBy) {
      const text = document.getElementById(ariaLabelledBy)?.textContent?.trim();
      if (text) return stripTrailingCountBadge(text);
    }
    const placeholder = el.getAttribute("placeholder");
    if (placeholder?.trim()) return placeholder.trim();
    const name = el.getAttribute("name");
    if (name) return humanize(name);
    if (el.id) return humanize(el.id);
    return "";
  }
  function stripTrailingCountBadge(text) {
    return text.replace(/\s+[\d][\d,]*$/, "").trim() || text;
  }
  function humanize(raw) {
    return raw.replace(/[-_]+/g, " ").replace(/([a-z])([A-Z])/g, "$1 $2").replace(/\s+/g, " ").trim().replace(/\b\w/g, (c) => c.toUpperCase());
  }

  // src/content.ts
  var marker = "__formAutomatorRecorderLoaded";
  if (!window[marker]) {
    window[marker] = true;
    init();
  }
  function init() {
    let recording = false;
    let toolbar = null;
    chrome.storage.local.get("recording", (state) => {
      setRecording(!!state.recording);
    });
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && "recording" in changes) {
        setRecording(!!changes.recording.newValue);
      }
    });
    function setRecording(next) {
      recording = next;
      if (recording && !toolbar) {
        toolbar = createToolbar({
          onStop: () => chrome.runtime.sendMessage({ type: "STOP_RECORDING" }).catch(() => {
          })
        });
      } else if (!recording && toolbar) {
        toolbar.destroy();
        toolbar = null;
      }
    }
    function sendStep(step) {
      chrome.runtime.sendMessage({ type: "RECORD_STEP", step }).catch(() => {
      });
    }
    function isFormField(el) {
      return el.tagName === "INPUT" || el.tagName === "TEXTAREA" || el.tagName === "SELECT";
    }
    function isContentEditable(el) {
      return el.isContentEditable === true;
    }
    function isOwnUi(el) {
      return !!el && el.id === "__formautomator_toolbar_host";
    }
    document.addEventListener(
      "click",
      (e) => {
        if (!recording) return;
        const target = e.target;
        if (!target || isOwnUi(target)) return;
        if (isFormField(target)) return;
        const label = target.closest("label");
        if (label) {
          const forId = label.getAttribute("for");
          const associated = forId ? document.getElementById(forId) : label.querySelector("input");
          const type = associated instanceof HTMLInputElement ? associated.type : "";
          if (type === "checkbox" || type === "radio") return;
        }
        const clickable = target.closest("button, a, [role=button], input[type=submit], input[type=button]") ?? target;
        sendStep({ type: "click", selectors: buildSelectorCandidates(clickable), timestamp: Date.now() });
      },
      true
    );
    document.addEventListener(
      "input",
      (e) => {
        if (!recording) return;
        const target = e.target;
        if (!target || target.tagName === "SELECT") return;
        if (isContentEditable(target)) {
          sendStep({
            type: "input",
            selectors: buildSelectorCandidates(target),
            value: target.innerText,
            inputType: "contenteditable",
            label: detectFieldLabel(target),
            timestamp: Date.now()
          });
          return;
        }
        if (!isFormField(target)) return;
        const input = target;
        const inputType = input.type ?? "text";
        if (inputType === "password") return;
        const isToggle = inputType === "checkbox" || inputType === "radio";
        sendStep({
          type: "input",
          selectors: buildSelectorCandidates(target),
          value: isToggle ? String(input.checked) : input.value,
          // A filter checkbox's own value attribute is the site's URL filter
          // token (booking.com: "mealplan=1") - kept alongside the checked state
          // so replay can apply the filter through the results URL instead of
          // clicking the checkbox on a page that may be bot-walled.
          nativeValue: isToggle ? input.value : void 0,
          inputType,
          label: detectFieldLabel(input),
          timestamp: Date.now()
        });
      },
      true
    );
    document.addEventListener(
      "change",
      (e) => {
        if (!recording) return;
        const target = e.target;
        if (!target || target.tagName !== "SELECT") return;
        const select = target;
        sendStep({
          type: "change",
          selectors: buildSelectorCandidates(target),
          value: select.value,
          label: detectFieldLabel(select),
          timestamp: Date.now()
        });
      },
      true
    );
    document.addEventListener(
      "keydown",
      (e) => {
        if (!recording) return;
        if (e.key !== "Enter") return;
        const target = e.target;
        if (!target || !isFormField(target)) return;
        sendStep({ type: "keydown", key: "Enter", selectors: buildSelectorCandidates(target), timestamp: Date.now() });
      },
      true
    );
  }
  function createToolbar(handlers) {
    const host = document.createElement("div");
    host.id = "__formautomator_toolbar_host";
    host.style.cssText = "position:fixed; top:12px; right:12px; z-index:2147483647;";
    const shadow = host.attachShadow({ mode: "open" });
    shadow.innerHTML = `
    <style>
      .bar { font-family: system-ui, sans-serif; background:#111827; color:white; padding:8px 10px;
             border-radius:10px; box-shadow:0 8px 24px rgba(0,0,0,.35); display:flex; align-items:center;
             gap:8px; font-size:13px; }
      .dot { width:8px; height:8px; border-radius:50%; background:#ef4444; flex-shrink:0; animation: pulse 1.2s infinite; }
      @keyframes pulse { 0%,100% { opacity:1 } 50% { opacity:.3 } }
      button { font-family: inherit; font-size:12px; padding:6px 10px; border-radius:6px; border:none; cursor:pointer; }
      .stop { background:#dc2626; color:white; }
    </style>
    <div class="bar">
      <span class="dot"></span>
      <span>Recording</span>
      <button class="stop">Stop</button>
    </div>
  `;
    document.documentElement.appendChild(host);
    const stopBtn = shadow.querySelector(".stop");
    stopBtn.addEventListener("click", handlers.onStop);
    return {
      destroy() {
        host.remove();
      }
    };
  }
})();
