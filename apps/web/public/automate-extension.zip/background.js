"use strict";
(() => {
  // src/config.ts
  var API_BASE = "http://localhost:4000/api";
  var WEB_BASE = "http://localhost:5173";

  // src/background.ts
  async function getState() {
    const stored = await chrome.storage.local.get([
      "recording",
      "steps",
      "outputFields",
      "startUrl",
      "recordingTabId"
    ]);
    return {
      recording: !!stored.recording,
      steps: stored.steps ?? [],
      outputFields: stored.outputFields ?? [],
      startUrl: stored.startUrl ?? "",
      recordingTabId: stored.recordingTabId ?? null
    };
  }
  async function setState(partial) {
    await chrome.storage.local.set(partial);
  }
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    handleMessage(message, sender).then(sendResponse).catch((err) => sendResponse({ ok: false, error: err instanceof Error ? err.message : String(err) }));
    return true;
  });
  async function handleMessage(message, sender) {
    switch (message?.type) {
      case "START_RECORDING":
        return startRecording();
      case "STOP_RECORDING":
        return stopRecording();
      case "GET_STATE":
        return reportState();
      case "RECORD_STEP":
        return recordStep(message.step, sender);
      case "CAPTURE_SESSION":
        return captureSession(message);
      case "ADD_OUTPUT_FIELD":
        return addOutputField(message.field, sender);
      default:
        return { ok: false, error: "Unknown message type" };
    }
  }
  async function startRecording() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    await setState({
      recording: true,
      steps: [],
      outputFields: [],
      startUrl: tab?.url ?? "",
      recordingTabId: tab?.id ?? null
    });
    if (tab?.id) {
      try {
        await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content.js"] });
      } catch {
      }
    }
    return { ok: true };
  }
  async function stopRecording() {
    const state = await getState();
    await setState({ recording: false });
    if (!state.startUrl || state.steps.length === 0) {
      return { ok: false, error: "Nothing was recorded." };
    }
    try {
      const draftId = await submitDraft(state.startUrl, state.steps, state.outputFields);
      await chrome.tabs.create({ url: `${WEB_BASE}/review/${draftId}` });
      return { ok: true, draftId };
    } catch (err) {
      return {
        ok: false,
        error: `Couldn't reach the AutoMATE server at ${API_BASE}. Is it running? (${err instanceof Error ? err.message : String(err)})`
      };
    }
  }
  async function reportState() {
    const state = await getState();
    return { recording: state.recording, stepCount: state.steps.length };
  }
  async function recordStep(incoming, sender) {
    const state = await getState();
    if (!state.recording) return { ok: false };
    if (sender.tab?.id !== state.recordingTabId) return { ok: false };
    const steps = [...state.steps];
    const last = steps[steps.length - 1];
    const coalesce = (incoming.type === "input" || incoming.type === "change") && last?.type === incoming.type && last.selectors?.[0] === incoming.selectors?.[0];
    if (coalesce) {
      steps[steps.length - 1] = incoming;
    } else {
      steps.push(incoming);
    }
    await setState({ steps });
    return { ok: true };
  }
  async function captureSession({ connectToken, url }) {
    const cookies = await chrome.cookies.getAll({ url });
    const res = await fetch(`${API_BASE}/automations/session/capture`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        connectToken,
        cookies: cookies.map((c) => ({
          name: c.name,
          value: c.value,
          domain: c.domain,
          path: c.path,
          secure: c.secure,
          httpOnly: c.httpOnly,
          sameSite: c.sameSite,
          expirationDate: c.expirationDate,
          hostOnly: c.hostOnly
        }))
      })
    });
    const body = await res.json().catch(() => ({}));
    if (!res.ok) return { ok: false, error: body?.error ?? `Capture failed (${res.status})` };
    return { ok: true };
  }
  async function addOutputField(field, sender) {
    const state = await getState();
    if (!state.recording) return { ok: false };
    if (sender.tab?.id !== state.recordingTabId) return { ok: false };
    const key = slugify(field.label, state.outputFields.length);
    await setState({ outputFields: [...state.outputFields, { key, label: field.label, selectors: field.selectors }] });
    return { ok: true };
  }
  function slugify(label, index) {
    const base = label.toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_+|_+$/g, "");
    return base || `field_${index + 1}`;
  }
  chrome.webNavigation.onCommitted.addListener((details) => recordNavigation(details));
  chrome.webNavigation.onHistoryStateUpdated.addListener((details) => recordNavigation(details));
  async function recordNavigation(details) {
    if (details.frameId !== 0) return;
    const state = await getState();
    if (!state.recording || details.tabId !== state.recordingTabId) return;
    if (state.steps.length === 0 && details.url === state.startUrl) return;
    const last = state.steps[state.steps.length - 1];
    if (last?.type === "navigate" && last.url === details.url) return;
    await setState({ steps: [...state.steps, { type: "navigate", url: details.url, timestamp: Date.now() }] });
  }
  async function submitDraft(startUrl, steps, outputFields) {
    const res = await fetch(`${API_BASE}/drafts`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ startUrl, steps, outputFields })
    });
    if (!res.ok) throw new Error(`Failed to submit recording: ${res.status}`);
    const data = await res.json();
    return data.id;
  }
})();
