"use strict";
(() => {
  // src/themeBridge.ts
  var STORAGE_KEY = "automate_theme";
  var THEME_SYNC_EVENT = "automate-theme-change";
  function currentModeFromLocalStorage() {
    const stored = localStorage.getItem(STORAGE_KEY);
    return stored === "light" || stored === "dark" ? stored : "system";
  }
  function syncMode(mode) {
    chrome.storage.local.set({ webThemeMode: mode });
  }
  syncMode(currentModeFromLocalStorage());
  window.addEventListener(THEME_SYNC_EVENT, (e) => {
    const mode = e.detail?.mode;
    if (mode) syncMode(mode);
  });
})();
