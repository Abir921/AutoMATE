"use strict";
(() => {
  // src/config.ts
  var WEB_BASE = "http://localhost:5173";

  // src/popup.ts
  chrome.storage.local.get("webThemeMode", (result) => {
    const mode = result.webThemeMode;
    if (mode === "light" || mode === "dark") {
      document.documentElement.dataset.theme = mode;
    }
  });
  var startBtn = document.getElementById("start");
  var stopBtn = document.getElementById("stop");
  var statusEl = document.getElementById("status");
  var errorEl = document.getElementById("error");
  var homeLink = document.getElementById("home-link");
  var connectTokenInput = document.getElementById("connect-token");
  var captureBtn = document.getElementById("capture-session");
  var sessionStatusEl = document.getElementById("session-status");
  homeLink.href = WEB_BASE;
  connectTokenInput.focus();
  captureBtn.addEventListener("click", async () => {
    sessionStatusEl.textContent = "";
    let connectToken = connectTokenInput.value.trim();
    if (!connectToken) {
      try {
        const clipboardText = (await navigator.clipboard.readText()).trim();
        if (clipboardText) {
          connectToken = clipboardText;
          connectTokenInput.value = clipboardText;
        }
      } catch {
      }
    }
    if (!connectToken) {
      sessionStatusEl.textContent = "Paste the connect code first.";
      return;
    }
    captureBtn.disabled = true;
    sessionStatusEl.textContent = "Capturing...";
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab?.url) {
        sessionStatusEl.textContent = "Couldn't read the current tab's URL.";
        return;
      }
      const result = await chrome.runtime.sendMessage({ type: "CAPTURE_SESSION", connectToken, url: tab.url });
      sessionStatusEl.textContent = result?.ok ? "Session captured - you can close this and run the automation." : result?.error ?? "Capture failed.";
      if (result?.ok) connectTokenInput.value = "";
    } catch (err) {
      sessionStatusEl.textContent = err instanceof Error ? err.message : "Could not reach the extension background.";
    } finally {
      captureBtn.disabled = false;
    }
  });
  function render(recording, stepCount = 0) {
    startBtn.style.display = recording ? "none" : "block";
    stopBtn.style.display = recording ? "block" : "none";
    statusEl.textContent = recording ? `Recording... ${stepCount} step(s) captured` : "Not recording";
  }
  async function refresh() {
    const state = await chrome.runtime.sendMessage({ type: "GET_STATE" });
    render(state?.recording ?? false, state?.stepCount ?? 0);
  }
  startBtn.addEventListener("click", async () => {
    errorEl.textContent = "";
    await chrome.runtime.sendMessage({ type: "START_RECORDING" });
    await refresh();
  });
  stopBtn.addEventListener("click", async () => {
    errorEl.textContent = "";
    try {
      const result = await chrome.runtime.sendMessage({ type: "STOP_RECORDING" });
      if (!result?.ok) {
        errorEl.textContent = result?.error ?? "Could not stop recording - no response from the extension background.";
      } else {
        window.close();
      }
    } catch (err) {
      errorEl.textContent = err instanceof Error ? err.message : "Could not reach the extension background.";
    }
    await refresh();
  });
  refresh();
  setInterval(refresh, 1e3);
})();
